/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.eletrofluxo.repository.interfaces;

import br.unipar.eletrofluxo.model.Cidade;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public interface CidadeRepositoryInterface {

    public Cidade inserir(Cidade cidade) throws SQLException;

    public Cidade atualizar(Cidade cidade) throws SQLException;

    public void deletar(Long id) throws SQLException;

    public Cidade findById(Long id) throws SQLException;

    public ArrayList<Cidade> listarTodos() throws SQLException;

}
